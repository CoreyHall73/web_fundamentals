var message = document.querySelector("#message");
function remove(element) {
    message.remove();
}