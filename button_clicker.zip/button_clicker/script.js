function hide(element) {
    element.remove();
}

function change(element) {
    element.innerText = "Logout";
}